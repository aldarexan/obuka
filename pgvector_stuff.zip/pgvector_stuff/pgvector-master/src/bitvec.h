#ifndef BITVEC_H
#define BITVEC_H

#include "utils/varbit.h"

VarBit	   *InitBitVector(int dim);

#endif
