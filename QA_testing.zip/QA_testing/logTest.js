// logTest.js
import fs from "fs";
import path from "path";
import { chromium } from "playwright";

// Simple logging function
function log(message) {
  const logPath = path.join(process.cwd(), "test-log.txt");
  const timestamp = new Date().toISOString();
  fs.appendFileSync(logPath, `[${timestamp}] ${message}\n`);
}

(async () => {
  // Launch browser
  const browser = await chromium.launch({ headless: false, slowMo: 1250 });
  const page = await browser.newPage();

  // Navigate to site
  await page.goto("https://test.webinars.rs/");
  log("Visited https://test.webinars.rs/");

  // Add more manual steps here if needed
  // e.g. await page.click("text=Login"); log("Clicked login button");

  // Close browser
  await browser.close();
  log("Browser closed");
})();
