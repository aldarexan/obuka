// logTest2.js
import fs from "fs";
import path from "path";
import readline from "readline";
import { chromium } from "playwright";

// Logging function
function log(message) {
  const logPath = path.join(process.cwd(), "test-log.txt");
  const timestamp = new Date().toISOString();
  fs.appendFileSync(logPath, `[${timestamp}] ${message}\n`);
  console.log(`Logged: ${message}`);
}

// Setup readline for manual notes
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

(async () => {
  // Launch browser visibly
  const browser = await chromium.launch({ headless: false, slowMo: 750 });
  const page = await browser.newPage();

  await page.goto("https://test.webinars.rs/");
  log("Browser opened at https://test.webinars.rs/");

  console.log("\nBrowser is open! Type your test notes below.");
  console.log("Type 'exit' when you’re done.\n");

  await page.goto("https://test.webinars.rs/");
  await page.getByRole("button", { name: "Prihvati" }).click();
  await page.getByRole("link", { name: "Početna" }).click();
  await page
    .locator("div")
    .filter({ hasText: "Tehnologija i IT" })
    .nth(2)
    .click();
  await page.locator(".slider").click();
  await page.locator(".flex.items-center.gap-3.rounded-lg").first().click();
  //Language change
  await page.locator("div").filter({ hasText: "Jezik" }).nth(4).click();
  await page.getByText("Engleski").click();
  await page.getByRole("link", { name: "Home" }).click();
  const page1Promise = page.waitForEvent("popup");
  await page.getByRole("button", { name: "Slušaj" }).click();
  //YouTube popup video
  const page1 = await page1Promise;
  await page1
    .getByRole("link", { name: "Žena u fokusu #1 - Dr. Stevan" })
    .click();
  await page1.locator("#owner").getByRole("link", { name: "Webinars" }).click();
  await page.getByRole("link", { name: "Zanimljivi svet pingvina:" }).click();
  await page.getByRole("link", { name: "Lekovite pečurke: Nauka," }).click();
  await page.getByRole("banner").getByRole("link", { name: "Kontakt" }).click();
  //Email form filling
  await page.getByRole("textbox", { name: "Ime i prezime *" }).click();
  await page
    .getByRole("textbox", { name: "Ime i prezime *" })
    .fill("Axel Rose");
  await page.getByRole("textbox", { name: "Ime i prezime *" }).press("Tab");
  await page.getByRole("textbox", { name: "Email *" }).fill("Axel@GNR.com");
  await page.getByRole("textbox", { name: "Email *" }).press("Tab");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .click();
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .fill("https://test.webinars.rs/kontakt e-mail test 2");
  await page.getByRole("button", { name: "Pošalji" }).click();
  //Pocetna
  await page.getByRole("button", { name: "Nazad na početnu" }).click();
  await page
    .getByRole("heading", { name: "Kreativnost i umetnost" })
    .nth(1)
    .click();
  const page2Promise = page.waitForEvent("popup");
  await page.locator(".flex.gap-4.icon-soc > a:nth-child(2)").click();
  const page2 = await page2Promise;
  await page2.getByRole("button", { name: "Close" }).click();
  await page
    .locator("#subcategories_container")
    .getByText("Muzika i produkcija")
    .click();
  await page.getByText("Tip Webinar Seminar Cena").click();

  //await context.close();
  //await browser.close();

  // Allow manual logging
  rl.on("line", async (input) => {
    if (input.trim().toLowerCase() === "exit") {
      rl.close();
      await browser.close();
      log("Browser closed");
      console.log("Test session ended.");
    } else {
      log(input);
    }
  });

  //await context.close();
  await browser.close();
})();

//Shljaka i FB.
