// checklist.test.js
import { test, expect } from "@playwright/test";
import fs from "fs";
import path from "path";

const logPath = path.join(process.cwd(), "test-log.txt");
const shotDir = path.join(process.cwd(), "screenshots");

// Ensure screenshot folder exists
if (!fs.existsSync(shotDir)) fs.mkdirSync(shotDir);

// Append a line to the log with timestamp
function log(message) {
  const timestamp = new Date().toISOString();
  fs.appendFileSync(logPath, `[${timestamp}] ${message}\n`);
  console.log(`Logged: ${message}`);
}

// Wrapper: log + screenshot
async function step(page, message, action) {
  log(message);
  await action();
  const safeName = message.replace(/[^a-z0-9-_]+/gi, "_").slice(0, 60);
  await page.screenshot({ path: path.join(shotDir, `${safeName}.png`) });
}

test("Navigation and links work", async ({ page }) => {
  await page.goto("https://your-site.com");
  await step(page, "Opened homepage", async () => {
    await expect(page).toHaveTitle(/Your Site/);
  });

  await step(page, "Clicked About link", async () => {
    await page.click("text=About");
    await expect(page).toHaveURL(/about/);
  });
});

test("Sign-up and login flow", async ({ page }) => {
  await page.goto("https://your-site.com/signup");

  await step(page, "Fill signup form", async () => {
    await page.fill("#username", "testuser");
    await page.fill("#password", "Password123!");
  });

  await step(page, "Submit signup form", async () => {
    await page.click("button[type=submit]");
  });

  await step(page, "Verify signup success", async () => {
    await expect(page.locator("text=Welcome")).toBeVisible();
  });
});

test("Search returns results", async ({ page }) => {
  await page.goto("https://your-site.com");

  await step(page, "Perform search", async () => {
    await page.fill("input[name=search]", "example");
    await page.press("input[name=search]", "Enter");
  });

  await step(page, "Verify search results", async () => {
    await expect(page.locator(".search-result")).toBeVisible();
  });
});

test("Checkout flow", async ({ page }) => {
  await page.goto("https://your-site.com/shop");

  await step(page, "Add item to cart", async () => {
    await page.click("text=Add to cart");
  });

  await step(page, "Proceed to checkout", async () => {
    await page.click("text=Checkout");
  });

  await step(page, "Submit payment form", async () => {
    await page.fill("#card-number", "4111111111111111");
    await page.fill("#expiry", "12/25");
    await page.fill("#cvc", "123");
    await page.click("text=Pay");
  });

  await step(page, "Verify order confirmation", async () => {
    await expect(page.locator("text=Order confirmed")).toBeVisible();
  });
});

test("Responsive layout check", async ({ page }) => {
  await page.goto("https://your-site.com");

  await step(page, "Switch to mobile viewport", async () => {
    await page.setViewportSize({ width: 375, height: 812 });
  });

  await step(page, "Verify mobile menu visible", async () => {
    await expect(page.locator("nav.mobile-menu")).toBeVisible();
  });
});

/*

How It Works
• 	:
• 	Logs the message into 
• 	Runs the Playwright action
• 	Saves a screenshot named after the step
• 	Screenshots are stored in a  folder.
• 	Each test block corresponds to a section of your checklist.
*/

//npx playwright test checklist.test.js --headed
