// checklist.test.js
import { test, expect } from "@playwright/test";
import fs from "fs";
import path from "path";

const logPath = path.join(process.cwd(), "test-log.txt");

function log(message) {
  const timestamp = new Date().toISOString();
  fs.appendFileSync(logPath, `[${timestamp}] ${message}\n`);
  console.log(`Logged: ${message}`);
}

// Navigation & Links
test("Navigation and links work", async ({ page }) => {
  await page.goto("https://your-site.com");
  log("Opened homepage");

  // Example: check a link
  await page.click("text=About");
  await expect(page).toHaveURL(/about/);
  log("Clicked About link and verified URL");
});

// User Accounts
test("Sign-up and login flow", async ({ page }) => {
  await page.goto("https://your-site.com/signup");
  log("Navigated to signup page");

  await page.fill("#username", "testuser");
  await page.fill("#password", "Password123!");
  await page.click("button[type=submit]");
  log("Submitted signup form");

  await expect(page.locator("text=Welcome")).toBeVisible();
  log("Verified signup success message");
});

// Search & Filters
test("Search returns results", async ({ page }) => {
  await page.goto("https://your-site.com");
  await page.fill("input[name=search]", "example");
  await page.press("input[name=search]", "Enter");
  log("Performed search for 'example'");

  await expect(page.locator(".search-result")).toBeVisible();
  log("Verified search results are visible");
});

// Shopping & Payments
test("Checkout flow", async ({ page }) => {
  await page.goto("https://your-site.com/shop");
  await page.click("text=Add to cart");
  log("Added item to cart");

  await page.click("text=Checkout");
  log("Navigated to checkout");

  // Example: fake card entry
  await page.fill("#card-number", "4111111111111111");
  await page.fill("#expiry", "12/25");
  await page.fill("#cvc", "123");
  await page.click("text=Pay");
  log("Submitted payment form");

  await expect(page.locator("text=Order confirmed")).toBeVisible();
  log("Verified order confirmation");
});

// Usability & UI
test("Responsive layout check", async ({ page }) => {
  await page.goto("https://your-site.com");
  await page.setViewportSize({ width: 375, height: 812 }); // iPhone X size
  log("Set viewport to mobile size");

  await expect(page.locator("nav.mobile-menu")).toBeVisible();
  log("Verified mobile menu visible");
});

//npm install @playwright/test
/*package.json - add "scripts": {
  "test": "playwright test"
}*/
// Then run with: npx playwright test checklist.test.js --headed
