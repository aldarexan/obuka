console.log("webinars_QA");

import fs from "fs";
import path from "path";
import { chromium } from "playwright";

function log(message) {
  const logPath = path.join(process.cwd(), "test-log.txt");
  const timestamp = new Date().toISOString();
  fs.appendFileSync(logPath, `[${timestamp}] ${message}\n`);
}

//ScreenShot
//await page.screenshot({ path: "screenshots/webinars_QA.png", fullPage: true });

// Get the page title
/*
const title = await page.title();
console.log("Page Title:", title);
*/

//Video
/*
const context = await browser.newContext({
  recordVideo: { dir: "videos" },
});
*/

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage();

  await page.goto("https://test.webinars.rs/");
  await page.getByRole("button", { name: "Prihvati" }).click();
  await page
    .getByText(
      "OTKRIJ DOGAĐAJE IZ CELOG SVETA Kreiraj webinare koji Povezuju Bilo da edukuje"
    )
    .click();
  await page.getByRole("link", { name: "Početna" }).click();
  await page.getByText("OTKRIJ DOGAĐAJE IZ CELOG SVETA").click();
  await page
    .getByRole("heading", { name: "Kreiraj webinare koji Edukuju" })
    .click();
  await page.getByRole("textbox", { name: "Pretraži webinare..." }).click();
  await page
    .getByRole("textbox", { name: "Pretraži webinare..." })
    .fill("Zdravlje i Wellness");
  await page.getByRole("button", { name: "Pretraži" }).click();
  await page
    .getByRole("main")
    .getByRole("heading", { name: "Tehnologija i IT" })
    .dblclick();
  await page
    .locator("div")
    .filter({ hasText: "Cybersecurity Istekao pre 4" })
    .nth(5)
    .click();
  await page.getByText("Svim ženama je potrebna").click();
  await page.getByRole("link", { name: "webinar.title" }).first().click();
  await page.getByText("Vlada AI").click();
  await page.getByText("Vladimir Krstic").dblclick();
  await page.getByRole("link", { name: "Početna" }).click();
  await page
    .getByRole("navigation")
    .getByRole("link", { name: "Blog" })
    .click();
  await page.getByText("Opšte teme o webinarima 10").click();
  await page
    .getByRole("heading", { name: "Direktna komunikacija s publikom" })
    .dblclick();
  await page
    .locator("div")
    .filter({ hasText: "Blogovi > Opšte teme o" })
    .first()
    .click();
  await page.getByRole("banner").getByRole("link", { name: "Blog" }).click();
  await page.getByRole("link", { name: "Trendovi i budućnost" }).click();
  await page
    .getByRole("link", { name: "Kako metaverzum može uticati" })
    .click();
  const page1Promise = page.waitForEvent("popup");
  await page.getByRole("link", { name: "Objavi na Facebook" }).click();
  const page1 = await page1Promise;
  await page1.getByTestId("royal-login-button").click();
  const page2Promise = page.waitForEvent("popup");
  await page.getByRole("link", { name: "Objavi na Facebook" }).click();
  const page2 = await page2Promise;
  await page2.getByTestId("royal-email").click();
  await page2.getByTestId("royal-email").fill("---");
  await page2.getByTestId("royal-pass").click();
  await page2.getByTestId("royal-pass").fill("---");
  await page2.getByTestId("royal-login-button").click();
  await page2
    .locator("#captcha-recaptcha")
    .contentFrame()
    .locator('iframe[name="a-qmzw89dfndt2"]')
    .contentFrame()
    .getByRole("checkbox", { name: "I'm not a robot" })
    .click();
  await page2
    .locator("#captcha-recaptcha")
    .contentFrame()
    .locator('iframe[name="c-qmzw89dfndt2"]')
    .contentFrame()
    .locator('[id="2"]')
    .dblclick();
  await page2
    .locator("#captcha-recaptcha")
    .contentFrame()
    .locator('iframe[name="c-qmzw89dfndt2"]')
    .contentFrame()
    .locator('[id="4"]')
    .click();
  await page2
    .locator("#captcha-recaptcha")
    .contentFrame()
    .locator('iframe[name="c-qmzw89dfndt2"]')
    .contentFrame()
    .locator('[id="6"]')
    .click();
  await page2
    .locator("#captcha-recaptcha")
    .contentFrame()
    .locator('iframe[name="c-qmzw89dfndt2"]')
    .contentFrame()
    .getByRole("button", { name: "Verify" })
    .click();
  await page2
    .locator("#captcha-recaptcha")
    .contentFrame()
    .locator('iframe[name="c-qmzw89dfndt2"]')
    .contentFrame()
    .locator('[id="2"]')
    .click();
  await page2
    .locator("#captcha-recaptcha")
    .contentFrame()
    .locator('iframe[name="c-qmzw89dfndt2"]')
    .contentFrame()
    .locator('[id="5"]')
    .click();
  await page2
    .locator("#captcha-recaptcha")
    .contentFrame()
    .locator('iframe[name="c-qmzw89dfndt2"]')
    .contentFrame()
    .getByRole("button", { name: "Verify" })
    .click();
  await page2.goto("https://www.facebook.com/share_channel/");
  await page2.getByRole("button", { name: "Share" }).click();
  await page2.goto("https://www.facebook.com/");
  await page2
    .getByRole("link", {
      name: "Aleksandar Njagulov Aleksandar Njagulov ---",
    })
    .getByLabel("Actions for this post")
    .click();
  await page.locator("div").filter({ hasText: "Kopiraj Link" }).nth(3).click();
  await page2.getByText("Move to trash").click();
  const page3Promise = page2.waitForEvent("popup");
  await page2.getByRole("button", { name: "Move" }).click();
  const page3 = await page3Promise;
  await page3.goto(
    "https://test.webinars.rs/blog/post/kako-metaverzum-moze-uticati-na-buducnost-webinara?fbclid=IwY2xjawOP2tdleHRuA2FlbQIxMQBzcnRjBmFwcF9pZBAyMjIwMzkxNzg4MjAwODkyAAEeI0Gw4GWdKHCKBLBzF5GKBDuRW5Tn_kJjafiWigaAhbTOQHzkkquHz-ulk68_aem_8zzNPqUgENJ4xSsG2hrd7w"
  );
  await page2
    .getByRole("button", { name: "Your profile", exact: true })
    .click();
  await page2.getByRole("button", { name: "Log Out" }).click();
  await page.getByRole("link", { name: "Paketi" }).click();
  await page.getByRole("button", { name: "Godišnje" }).click();
  await page
    .getByRole("navigation")
    .getByRole("link", { name: "Kontakt" })
    .click();
  await page.getByRole("textbox", { name: "Ime i prezime *" }).click();
  await page
    .getByRole("textbox", { name: "Ime i prezime *" })
    .fill("Axel Rose");
  await page.getByRole("textbox", { name: "Ime i prezime *" }).press("Tab");
  await page.getByRole("textbox", { name: "Email *" }).fill("GNR");
  await page.getByRole("textbox", { name: "Email *" }).press("ArrowLeft");
  await page.getByRole("textbox", { name: "Email *" }).press("ArrowLeft");
  await page.getByRole("textbox", { name: "Email *" }).press("ArrowLeft");
  await page.getByRole("textbox", { name: "Email *" }).fill("Rose@GNR");
  await page.getByRole("textbox", { name: "Email *" }).press("ArrowRight");
  await page.getByRole("textbox", { name: "Email *" }).press("ArrowRight");
  await page.getByRole("textbox", { name: "Email *" }).press("ArrowRight");
  await page.getByRole("textbox", { name: "Email *" }).fill("Rose@GNR.com");
  await page.getByRole("textbox", { name: "Email *" }).press("Tab");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .click();
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .fill("test");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .press("ArrowLeft");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .press("ArrowLeft");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .press("ArrowLeft");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .press("ArrowLeft");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .fill("email test");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .click();
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .press("ArrowLeft");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .press("ArrowLeft");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .press("ArrowLeft");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .press("ArrowLeft");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .press("ArrowLeft");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .press("ArrowLeft");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .press("ArrowLeft");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .press("ArrowLeft");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .fill(
      "https://test.webinars.rs/blog/post/kako-metaverzum-moze-uticati-na-buducnost-webinara email test"
    );
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .click();
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .click();
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .dblclick();
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .press("ArrowLeft");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .press("ArrowLeft");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .press("ControlOrMeta+Shift+ArrowLeft");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .press("ControlOrMeta+Shift+ArrowLeft");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .press("ControlOrMeta+Shift+ArrowLeft");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .press("ControlOrMeta+Shift+ArrowLeft");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .press("ControlOrMeta+Shift+ArrowLeft");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .press("ControlOrMeta+Shift+ArrowLeft");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .press("ControlOrMeta+Shift+ArrowLeft");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .press("ControlOrMeta+Shift+ArrowLeft");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .press("ControlOrMeta+Shift+ArrowLeft");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .press("ControlOrMeta+Shift+ArrowLeft");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .press("ControlOrMeta+Shift+ArrowLeft");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .press("ControlOrMeta+Shift+ArrowLeft");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .press("ControlOrMeta+Shift+ArrowLeft");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .press("ControlOrMeta+Shift+ArrowLeft");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .press("ControlOrMeta+Shift+ArrowLeft");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .press("ControlOrMeta+Shift+ArrowLeft");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .press("ControlOrMeta+Shift+ArrowLeft");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .press("ControlOrMeta+Shift+ArrowLeft");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .press("ControlOrMeta+Shift+ArrowLeft");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .fill("https://test.webinars.rs/kontakt email test");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .press("ArrowRight");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .press("ArrowRight");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .fill("https://test.webinars.rs/kontakt e-mail test");
  await page.getByRole("button", { name: "Pošalji" }).click();
  await page.getByRole("button", { name: "Nazad na početnu" }).click();
  await page
    .getByRole("main")
    .getByRole("heading", { name: "Kreativnost i umetnost" })
    .click();
  await page
    .locator("#subcategories_container")
    .getByText("Grafički dizajn")
    .click();
  await page.locator(".flex.flex-wrap > div:nth-child(3)").first().click();
  await page.locator("div:nth-child(3) > .ml-1").dblclick();
  await page.getByRole("button", { name: "Zdravlje i Wellness" }).dblclick();
  await page.getByRole("button", { name: "Zdravlje i Wellness" }).click();
  await page.getByRole("checkbox", { name: "Mentalno zdravlje" }).check();
  await page.goto(
    "https://test.webinars.rs/webinari?types%5B%5D=19&types%5B%5D=21&types%5B%5D=13"
  );
  await page.getByRole("button", { name: "Tehnologija i IT" }).click();
  await page.getByText("Cybersecurity").click();
  await page.getByText("Svim ženama je potrebna").click();
  await page.getByRole("link", { name: "webinar.title" }).click();
  await page.locator(".space-y-4 > div:nth-child(2) > .flex.flex-col").click();
  await page.getByRole("button", { name: "Prijava", exact: true }).click();
  await page.goto("https://test.webinars.rs/");
  await page.getByText("Edukuju").click();
})();
