// logTest2.js
import fs from "fs";
import path from "path";
import readline from "readline";
import { chromium } from "playwright";

// Logging function
function log(message) {
  const logPath = path.join(process.cwd(), "test-log.txt");
  const timestamp = new Date().toISOString();
  fs.appendFileSync(logPath, `[${timestamp}] ${message}\n`);
  console.log(`Logged: ${message}`);
}

// Setup readline for manual notes
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

(async () => {
  // Launch browser visibly
  const browser = await chromium.launch({ headless: false });
  const page = await browser.newPage();

  await page.goto("https://test.webinars.rs/");
  log("Browser opened at https://test.webinars.rs/");

  console.log("\nBrowser is open! Type your test notes below.");
  console.log("Type 'exit' when you’re done.\n");

  // Allow manual logging
  rl.on("line", async (input) => {
    if (input.trim().toLowerCase() === "exit") {
      rl.close();
      await browser.close();
      log("Browser closed");
      console.log("Test session ended.");
    } else {
      log(input);
    }
  });
})();
