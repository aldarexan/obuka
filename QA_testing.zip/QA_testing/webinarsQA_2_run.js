console.log("Drugi put:");
//npx playwright codegen https://test.webinars.rs/

const { chromium } = require("playwright");

(async ({ page }) => {
  await page.goto("https://test.webinars.rs/");
  await page.locator("#cookie-popup").click();
  await page.getByRole("button", { name: "Prihvati" }).click();
  await page
    .getByRole("navigation")
    .getByRole("link", { name: "Kontakt" })
    .click();
  await page.getByRole("link", { name: "Paketi" }).click();
  await page.getByRole("button", { name: "Godišnje" }).dblclick();
  await page
    .getByRole("navigation")
    .getByRole("link", { name: "Blog" })
    .click();
  await page.getByRole("link", { name: "Case studies" }).click();
  await page.getByRole("link", { name: "Analitika i uspeh" }).click();
  await page.getByRole("link", { name: "Kako koristiti AI i" }).click();
  await page.getByRole("heading", { name: "Zaključak" }).click();
  await page.getByRole("link", { name: "Politika Privatnosti" }).click();
  await page
    .getByRole("contentinfo")
    .getByRole("link", { name: "Blog" })
    .click();

  await context.close();
  await browser.close();
})();

//npx playwright codegen https://www.facebook.com/

import { test, expect } from "@playwright/test";

test("test", async ({ page }) => {
  await page.goto("https://test.webinars.rs/");
  await page.getByRole("button", { name: "Prihvati" }).click();
  await page.getByRole("link", { name: "Početna" }).click();
  await page
    .locator("div")
    .filter({ hasText: "Tehnologija i IT" })
    .nth(2)
    .click();
  await page.locator(".slider").click();
  await page.locator(".flex.items-center.gap-3.rounded-lg").first().click();
  await page.locator("div").filter({ hasText: "Jezik" }).nth(4).click();
  await page.getByText("Engleski").click();
  await page.getByRole("link", { name: "Home" }).click();
  const page1Promise = page.waitForEvent("popup");
  await page.getByRole("button", { name: "Slušaj" }).click();
  const page1 = await page1Promise;
  await page1
    .getByRole("link", { name: "Žena u fokusu #1 - Dr. Stevan" })
    .click();
  await page1.locator("#owner").getByRole("link", { name: "Webinars" }).click();
  await page.getByRole("link", { name: "Zanimljivi svet pingvina:" }).click();
  await page.getByRole("link", { name: "Lekovite pečurke: Nauka," }).click();
  await page.getByRole("banner").getByRole("link", { name: "Kontakt" }).click();
  await page.getByRole("textbox", { name: "Ime i prezime *" }).click();
  await page
    .getByRole("textbox", { name: "Ime i prezime *" })
    .fill("Axel Rose");
  await page.getByRole("textbox", { name: "Ime i prezime *" }).press("Tab");
  await page.getByRole("textbox", { name: "Email *" }).fill("Axel@GNR.com");
  await page.getByRole("textbox", { name: "Email *" }).press("Tab");
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .click();
  await page
    .getByRole("textbox", { name: "Šta bi bilo korisno znati pre" })
    .fill("https://test.webinars.rs/kontakt e-mail test 2");
  await page.getByRole("button", { name: "Pošalji" }).click();
  await page.getByRole("button", { name: "Nazad na početnu" }).click();
  await page
    .getByRole("heading", { name: "Kreativnost i umetnost" })
    .nth(1)
    .click();
  const page2Promise = page.waitForEvent("popup");
  await page.locator(".flex.gap-4.icon-soc > a:nth-child(2)").click();
  const page2 = await page2Promise;
  await page2.getByRole("button", { name: "Close" }).click();
  await page
    .locator("#subcategories_container")
    .getByText("Muzika i produkcija")
    .click();
  await page.getByText("Tip Webinar Seminar Cena").click();

  await context.close();
  await browser.close();
});
