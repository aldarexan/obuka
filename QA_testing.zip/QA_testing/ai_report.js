// report.js
import fs from "fs";
import path from "path";

const logPath = path.join(process.cwd(), "test-log.txt");
const shotDir = path.join(process.cwd(), "screenshots");
const reportPath = path.join(process.cwd(), "report.html");

// Read log file
const logEntries = fs.existsSync(logPath)
  ? fs.readFileSync(logPath, "utf-8").split("\n").filter(Boolean)
  : [];

// Collect screenshots
const screenshots = fs.existsSync(shotDir)
  ? fs.readdirSync(shotDir).filter((f) => f.endsWith(".png"))
  : [];

// Build HTML
let html = `
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Test Report</title>
<style>
  body { font-family: Arial, sans-serif; margin: 20px; }
  h1 { color: #333; }
  .entry { margin-bottom: 20px; }
  .entry img { max-width: 600px; border: 1px solid #ccc; margin-top: 5px; }
  .timestamp { color: #666; font-size: 0.9em; }
</style>
</head>
<body>
<h1>Web App Test Report</h1>
`;

// Match log entries with screenshots by order
logEntries.forEach((line, i) => {
  const screenshot = screenshots[i];
  html += `<div class="entry">
    <div class="timestamp">${line}</div>`;
  if (screenshot) {
    html += `<img src="screenshots/${screenshot}" alt="Step screenshot">`;
  }
  html += `</div>`;
});

html += `
</body>
</html>
`;

// Write report
fs.writeFileSync(reportPath, html, "utf-8");
console.log(`Report generated: ${reportPath}`);

//run node ai_report.js
