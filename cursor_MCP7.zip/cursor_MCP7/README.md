# MCP Configuration

This workspace includes a minimal Model Context Protocol (MCP) configuration.

## Files

- `.\\cursor mcp 7.json`: Source config you provided
- `.cursor/mcp.json`: Normalized config for Cursor MCP integration
- `scripts/validate-mcp-config.js`: Schema check and pretty-print utility

## Schema (expected)

```json
{
  "mcpServers": {
    "<serverName>": {
      // Either a remote MCP server:
      "url": "https://example.com/mcp"
      
      // Or a local MCP server via command:
      // "command": "node",
      // "args": ["path/to/server.js"]
    }
  }
}
```

Each server entry must have either `url` (string) or `command` (string) with optional `args` (string array).

## Usage

- Cursor will read `.cursor/mcp.json` automatically if present.
- To validate and inspect the configuration:

```bash
node scripts/validate-mcp-config.js
```

This prints a summary and exits non-zero if validation fails.
