# JWT Authentication System

A complete JWT authentication system with multiple implementations from basic to advanced.

## Files Overview

### Basic Implementation

- `jwt_server.py` - Basic JWT server (issue/verify tokens)
- `jwt_front.html` - Basic HTML frontend
- `jwt_js_front.html` - JavaScript-enhanced frontend

### Enhanced Implementation

- `jwt_auth_server.py` - MySQL-backed auth server (signup/login)
- `jwt_auth_front.html` - Simple signup/login UI

### Advanced Implementation

- `jwt_auth_enhanced.py` - Production-ready server with refresh tokens, validation, rate limiting
- `jwt_auth_enhanced_front.html` - Complete UI with profile management
- `test_jwt_auth.py` - Comprehensive test suite
- `config.env.example` - Environment configuration template

## Quick Start

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Setup Database

- Start XAMPP MySQL on localhost:3306
- Create database `examples`
- Copy `config.env.example` to `config.env` and adjust settings

### 3. Run Enhanced Server

```bash
python jwt_auth_enhanced.py
```

### 4. Open Frontend

Open `jwt_auth_enhanced_front.html` in your browser

## Features

### Enhanced Server Features

- ✅ Environment-based configuration
- ✅ Access + Refresh token system
- ✅ Input validation and sanitization
- ✅ Rate limiting and security
- ✅ Comprehensive error handling
- ✅ Database migrations
- ✅ Structured logging
- ✅ CORS support
- ✅ PBKDF2 password hashing

### API Endpoints

- `POST /signup` - Create new user account
- `POST /login` - Authenticate user
- `POST /refresh` - Refresh access token
- `POST /logout` - Invalidate refresh token
- `GET /profile` - Get user profile (requires auth)

### Frontend Features

- ✅ Modern, responsive UI
- ✅ Form validation
- ✅ Token management
- ✅ Profile access
- ✅ Auto-refresh tokens
- ✅ Local storage persistence
- ✅ Error handling

## Testing

Run the test suite:

```bash
python test_jwt_auth.py
```

Tests cover:

- User signup/login flows
- Token refresh/logout
- Profile access
- Input validation
- Error handling
- Security features

## Configuration

Edit `config.env` to customize:

- Database connection
- JWT secrets and expiry times
- Server port and CORS settings
- Security parameters

## Security Notes

- Passwords are hashed with PBKDF2-HMAC-SHA256
- Rate limiting prevents brute force attacks
- Tokens have configurable expiry times
- Refresh tokens are stored securely in database
- Input validation prevents injection attacks

## Production Considerations

For production deployment, consider:

- Use environment variables for secrets
- Implement proper logging and monitoring
- Add HTTPS/TLS encryption
- Use Redis for rate limiting
- Add database connection pooling
- Implement proper backup strategies
- Add health check endpoints
