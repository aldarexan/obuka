"""JWT auth server with MySQL (XAMPP) for signup/login

Endpoints (JSON over HTTP):
  - POST /signup -> { username, password, secret?, exp_seconds? }
                    Creates user if not exists and returns { token, user }
  - POST /login  -> { username, password, secret?, exp_seconds? }
                    Verifies credentials and returns { token, user }

Notes:
  - Default MySQL (XAMPP) connection uses user "root" with empty password.
  - Database: examples; Table auto-created: users
  - Server runs on http://localhost:8001

Run: python jwt_auth_server.py
Open: jwt_auth_front.html in your browser
"""
import json
import time
import secrets
import hashlib
from typing import Tuple, Optional

import jwt

try:
    import pymysql  # Pure-Python MySQL client (easy to install)
    from pymysql.cursors import DictCursor
except Exception as e:  # pragma: no cover
    raise SystemExit("pymysql is required. Install with: pip install pymysql") from e

import socketserver
from http.server import BaseHTTPRequestHandler


DEFAULT_JWT_SECRET = "CHANGE_ME_SECRET"
JWT_ALG = "HS256"


def get_db_connection():
    """Create a new DB connection to the XAMPP MySQL server."""
    # Adjust user/password if your XAMPP config differs
    return pymysql.connect(
        host="localhost",
        port=3306,
        user="root",
        password="",
        database="examples",
        autocommit=True,
        cursorclass=DictCursor,
    )


def ensure_schema_exists() -> None:
    """Create the users table if it doesn't already exist."""
    create_sql = (
        """
        CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(255) NOT NULL UNIQUE,
            password_hash VARCHAR(255) NOT NULL,
            password_salt VARCHAR(255) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        """
    )
    with get_db_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(create_sql)


def pbkdf2_hash_password(password: str, salt_hex: Optional[str] = None) -> Tuple[str, str]:
    """Return (hash_hex, salt_hex) using PBKDF2-HMAC-SHA256."""
    if salt_hex is None:
        salt = secrets.token_bytes(16)
        salt_hex = salt.hex()
    else:
        salt = bytes.fromhex(salt_hex)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 100_000)
    return dk.hex(), salt_hex


def verify_password(password: str, stored_hash_hex: str, stored_salt_hex: str) -> bool:
    calc_hash_hex, _ = pbkdf2_hash_password(password, stored_salt_hex)
    # Constant-time compare
    return secrets.compare_digest(calc_hash_hex, stored_hash_hex)


class AuthHTTPRequestHandler(BaseHTTPRequestHandler):
    def _set_headers_json(self, code: int = 200) -> None:
        self.send_response(code)
        self.send_header("Content-type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
        self.end_headers()

    def do_OPTIONS(self):  # CORS preflight
        self._set_headers_json(204)

    def _read_json_body(self) -> Tuple[Optional[dict], Optional[str]]:
        try:
            content_length = int(self.headers.get("Content-Length", "0"))
        except Exception:
            content_length = 0
        raw_body = self.rfile.read(content_length) if content_length > 0 else b""
        try:
            body = json.loads(raw_body.decode("utf-8") or "{}")
            return body, None
        except Exception:
            return None, "Invalid JSON"

    def _issue_token(self, user_row: dict, secret: Optional[str], exp_seconds: Optional[int]) -> str:
        payload = {
            "user_id": int(user_row["id"]),
            "username": user_row["username"],
        }
        if isinstance(exp_seconds, int) and exp_seconds > 0:
            payload["exp"] = int(time.time()) + exp_seconds
        token = jwt.encode(payload, secret or DEFAULT_JWT_SECRET, algorithm=JWT_ALG)
        if isinstance(token, bytes):
            token = token.decode("utf-8")
        return token

    def do_POST(self):
        body, err = self._read_json_body()
        if err:
            self._set_headers_json(400)
            self.wfile.write(json.dumps({"error": err}).encode("utf-8"))
            return

        path = self.path
        if path not in ("/signup", "/login"):
            self._set_headers_json(404)
            self.wfile.write(json.dumps({"error": "Not found"}).encode("utf-8"))
            return

        assert body is not None
        username = (body.get("username") or "").strip()
        password = (body.get("password") or "")
        secret = body.get("secret")
        exp_seconds = body.get("exp_seconds")

        if not username or not password:
            self._set_headers_json(400)
            self.wfile.write(json.dumps({"error": "'username' and 'password' are required"}).encode("utf-8"))
            return

        try:
            ensure_schema_exists()
            with get_db_connection() as conn:
                with conn.cursor() as cur:
                    if path == "/signup":
                        # Check if exists
                        cur.execute("SELECT id, username FROM users WHERE username=%s", (username,))
                        existing = cur.fetchone()
                        if existing:
                            self._set_headers_json(409)
                            self.wfile.write(json.dumps({"error": "username already exists"}).encode("utf-8"))
                            return

                        pw_hash, pw_salt = pbkdf2_hash_password(password)
                        cur.execute(
                            "INSERT INTO users (username, password_hash, password_salt) VALUES (%s, %s, %s)",
                            (username, pw_hash, pw_salt),
                        )
                        user_id = cur.lastrowid
                        user_row = {"id": user_id, "username": username}
                        token = self._issue_token(user_row, secret, exp_seconds)
                        self._set_headers_json(200)
                        self.wfile.write(
                            json.dumps({"token": token, "user": user_row}).encode("utf-8")
                        )
                        return

                    if path == "/login":
                        cur.execute(
                            "SELECT id, username, password_hash, password_salt FROM users WHERE username=%s",
                            (username,),
                        )
                        user = cur.fetchone()
                        if not user or not verify_password(password, user["password_hash"], user["password_salt"]):
                            self._set_headers_json(401)
                            self.wfile.write(json.dumps({"error": "invalid credentials"}).encode("utf-8"))
                            return

                        user_row = {"id": user["id"], "username": user["username"]}
                        token = self._issue_token(user_row, secret, exp_seconds)
                        self._set_headers_json(200)
                        self.wfile.write(
                            json.dumps({"token": token, "user": user_row}).encode("utf-8")
                        )
                        return
        except Exception as e:
            self._set_headers_json(500)
            self.wfile.write(json.dumps({"error": f"server error: {e}"}).encode("utf-8"))
            return


with socketserver.TCPServer(("", 8001), AuthHTTPRequestHandler) as httpd:
    print("Auth server serving on port 8001...")
    httpd.serve_forever()


