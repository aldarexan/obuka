import jwt
import time
import socketserver
from http.server import BaseHTTPRequestHandler

# Secret key for signing the JWT
SECRET_KEY = 'your-super-secret-key'

class SimpleHTTPRequestHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        # Generate a JWT token
        payload = {
            'user_id': 123,
            'exp': time.time() + 360  # Token expires in 6 minutes
        }
        token = jwt.encode(payload, SECRET_KEY, algorithm='HS256').encode('utf-8')
        print(token)
        # Send a response with the token
        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.end_headers()
        self.wfile.write(f"""
        <html>
        <head>
            <title>JWT Example</title>
        </head>
        <body>
            <h1>JWT Example <a href='https://www.jwt.io/'>check jwt</a></h1>
            <script>
                console.log('ok');
                // Store the JWT token in the browser's local storage
                localStorage.setItem('jwt_token', '{token.decode('utf-8')}',);
                console.log('JWT token stored in local storage:', localStorage.getItem('jwt_token'));
            </script>
        </body>
        </html>
        """.encode())

# Run the server on port 8000
with socketserver.TCPServer(("", 8000), SimpleHTTPRequestHandler) as httpd:
    print("Serving on port 8000...")
    httpd.serve_forever()