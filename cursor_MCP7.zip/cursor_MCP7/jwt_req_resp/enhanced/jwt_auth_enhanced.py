"""Enhanced JWT Auth Server with Environment Config, Refresh Tokens, Validation, and Tests

Features:
- Environment-based configuration
- Access + Refresh token system
- Input validation and rate limiting
- Comprehensive error handling
- Database migrations
- Structured logging

Endpoints:
- POST /signup -> { username, password, email? }
- POST /login -> { username, password }
- POST /refresh -> { refresh_token }
- POST /logout -> { refresh_token }
- GET /profile -> requires Authorization header

Run: python jwt_auth_enhanced.py
"""
import json
import time
import secrets
import hashlib
import os
import logging
from typing import Dict, Optional, Tuple
from dataclasses import dataclass
from collections import defaultdict

import jwt
from jwt import InvalidTokenError

try:
    import pymysql
    from pymysql.cursors import DictCursor
except ImportError:
    raise SystemExit("pymysql required: pip install pymysql")

import socketserver
from http.server import BaseHTTPRequestHandler


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


@dataclass
class Config:
    """Configuration loaded from environment variables."""
    # Database
    db_host: str = "localhost"
    db_port: int = 3306
    db_user: str = "root"
    db_password: str = ""
    db_name: str = "examples"
    
    # JWT
    jwt_access_secret: str = "access-secret-change-me"
    jwt_refresh_secret: str = "refresh-secret-change-me"
    access_token_expiry: int = 3600  # 1 hour
    refresh_token_expiry: int = 604800  # 7 days
    
    # Server
    server_host: str = ""
    server_port: int = 8002
    cors_origin: str = "*"
    
    # Security
    password_min_length: int = 6
    max_login_attempts: int = 5
    rate_limit_window: int = 300  # 5 minutes


def load_config() -> Config:
    """Load configuration from environment variables."""
    config = Config()
    
    # Load from config.env if it exists
    if os.path.exists("config.env"):
        with open("config.env", "r") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, value = line.split("=", 1)
                    key = key.strip().lower()
                    value = value.strip()
                    
                    # Map to config attributes
                    if key == "db_host":
                        config.db_host = value
                    elif key == "db_port":
                        config.db_port = int(value)
                    elif key == "db_user":
                        config.db_user = value
                    elif key == "db_password":
                        config.db_password = value
                    elif key == "db_name":
                        config.db_name = value
                    elif key == "jwt_access_secret":
                        config.jwt_access_secret = value
                    elif key == "jwt_refresh_secret":
                        config.jwt_refresh_secret = value
                    elif key == "access_token_expiry":
                        config.access_token_expiry = int(value)
                    elif key == "refresh_token_expiry":
                        config.refresh_token_expiry = int(value)
                    elif key == "server_host":
                        config.server_host = value
                    elif key == "server_port":
                        config.server_port = int(value)
                    elif key == "cors_origin":
                        config.cors_origin = value
                    elif key == "password_min_length":
                        config.password_min_length = int(value)
                    elif key == "max_login_attempts":
                        config.max_login_attempts = int(value)
                    elif key == "rate_limit_window":
                        config.rate_limit_window = int(value)
    
    # Override with environment variables
    config.db_host = os.getenv("DB_HOST", config.db_host)
    config.db_port = int(os.getenv("DB_PORT", config.db_port))
    config.db_user = os.getenv("DB_USER", config.db_user)
    config.db_password = os.getenv("DB_PASSWORD", config.db_password)
    config.db_name = os.getenv("DB_NAME", config.db_name)
    
    config.jwt_access_secret = os.getenv("JWT_ACCESS_SECRET", config.jwt_access_secret)
    config.jwt_refresh_secret = os.getenv("JWT_REFRESH_SECRET", config.jwt_refresh_secret)
    config.access_token_expiry = int(os.getenv("ACCESS_TOKEN_EXPIRY", config.access_token_expiry))
    config.refresh_token_expiry = int(os.getenv("REFRESH_TOKEN_EXPIRY", config.refresh_token_expiry))
    
    config.server_host = os.getenv("SERVER_HOST", config.server_host)
    config.server_port = int(os.getenv("SERVER_PORT", config.server_port))
    config.cors_origin = os.getenv("CORS_ORIGIN", config.cors_origin)
    
    config.password_min_length = int(os.getenv("PASSWORD_MIN_LENGTH", config.password_min_length))
    config.max_login_attempts = int(os.getenv("MAX_LOGIN_ATTEMPTS", config.max_login_attempts))
    config.rate_limit_window = int(os.getenv("RATE_LIMIT_WINDOW", config.rate_limit_window))
    
    return config


# Global config instance
config = load_config()

# Rate limiting storage (in production, use Redis)
login_attempts = defaultdict(list)
request_counts = defaultdict(list)


def get_db_connection():
    """Create database connection using config."""
    return pymysql.connect(
        host=config.db_host,
        port=config.db_port,
        user=config.db_user,
        password=config.db_password,
        database=config.db_name,
        autocommit=True,
        cursorclass=DictCursor,
    )


def ensure_schema_exists() -> None:
    """Create database schema if it doesn't exist."""
    create_users_sql = """
    CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(255) NOT NULL UNIQUE,
        email VARCHAR(255) UNIQUE,
        password_hash VARCHAR(255) NOT NULL,
        password_salt VARCHAR(255) NOT NULL,
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    """
    
    create_refresh_tokens_sql = """
    CREATE TABLE IF NOT EXISTS refresh_tokens (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        token_hash VARCHAR(255) NOT NULL UNIQUE,
        expires_at TIMESTAMP NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        INDEX idx_user_id (user_id),
        INDEX idx_expires_at (expires_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    """
    
    try:
        with get_db_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(create_users_sql)
                cur.execute(create_refresh_tokens_sql)
        logger.info("Database schema ensured")
    except Exception as e:
        logger.error(f"Failed to create schema: {e}")
        raise


def validate_input(data: dict, required_fields: list, validators: dict = None) -> Tuple[bool, str]:
    """Validate input data."""
    if validators is None:
        validators = {}
    
    # Check required fields
    for field in required_fields:
        if field not in data or not data[field]:
            return False, f"Missing required field: {field}"
    
    # Apply custom validators
    for field, validator in validators.items():
        if field in data:
            is_valid, message = validator(data[field])
            if not is_valid:
                return False, message
    
    return True, ""


def validate_username(username: str) -> Tuple[bool, str]:
    """Validate username."""
    if len(username) < 3:
        return False, "Username must be at least 3 characters"
    if len(username) > 50:
        return False, "Username must be less than 50 characters"
    if not username.replace("_", "").replace("-", "").isalnum():
        return False, "Username can only contain letters, numbers, _, and -"
    return True, ""


def validate_password(password: str) -> Tuple[bool, str]:
    """Validate password."""
    if len(password) < config.password_min_length:
        return False, f"Password must be at least {config.password_min_length} characters"
    if len(password) > 128:
        return False, "Password must be less than 128 characters"
    return True, ""


def validate_email(email: str) -> Tuple[bool, str]:
    """Basic email validation."""
    if "@" not in email or "." not in email:
        return False, "Invalid email format"
    return True, ""


def pbkdf2_hash_password(password: str, salt_hex: Optional[str] = None) -> Tuple[str, str]:
    """Hash password using PBKDF2-HMAC-SHA256."""
    if salt_hex is None:
        salt = secrets.token_bytes(16)
        salt_hex = salt.hex()
    else:
        salt = bytes.fromhex(salt_hex)
    
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 100_000)
    return dk.hex(), salt_hex


def verify_password(password: str, stored_hash_hex: str, stored_salt_hex: str) -> bool:
    """Verify password against stored hash."""
    calc_hash_hex, _ = pbkdf2_hash_password(password, stored_salt_hex)
    return secrets.compare_digest(calc_hash_hex, stored_hash_hex)


def check_rate_limit(client_ip: str, endpoint: str) -> bool:
    """Check if client is rate limited."""
    now = time.time()
    window_start = now - config.rate_limit_window
    
    # Clean old entries
    if endpoint == "login":
        login_attempts[client_ip] = [t for t in login_attempts[client_ip] if t > window_start]
        return len(login_attempts[client_ip]) < config.max_login_attempts
    else:
        request_counts[client_ip] = [t for t in request_counts[client_ip] if t > window_start]
        return len(request_counts[client_ip]) < 100  # General rate limit


def record_request(client_ip: str, endpoint: str):
    """Record request for rate limiting."""
    now = time.time()
    if endpoint == "login":
        login_attempts[client_ip].append(now)
    else:
        request_counts[client_ip].append(now)


def generate_tokens(user_id: int, username: str) -> Tuple[str, str]:
    """Generate access and refresh tokens."""
    now = int(time.time())
    
    # Access token
    access_payload = {
        "user_id": user_id,
        "username": username,
        "type": "access",
        "iat": now,
        "exp": now + config.access_token_expiry
    }
    access_token = jwt.encode(access_payload, config.jwt_access_secret, algorithm="HS256")
    
    # Refresh token
    refresh_token = secrets.token_urlsafe(32)
    refresh_payload = {
        "user_id": user_id,
        "username": username,
        "type": "refresh",
        "iat": now,
        "exp": now + config.refresh_token_expiry
    }
    signed_refresh = jwt.encode(refresh_payload, config.jwt_refresh_secret, algorithm="HS256")
    
    # Store refresh token in database
    token_hash = hashlib.sha256(refresh_token.encode()).hexdigest()
    expires_at = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(now + config.refresh_token_expiry))
    
    with get_db_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "INSERT INTO refresh_tokens (user_id, token_hash, expires_at) VALUES (%s, %s, %s)",
                (user_id, token_hash, expires_at)
            )
    
    return access_token, refresh_token


def verify_access_token(token: str) -> Optional[dict]:
    """Verify access token and return payload."""
    try:
        payload = jwt.decode(token, config.jwt_access_secret, algorithms=["HS256"])
        if payload.get("type") != "access":
            return None
        return payload
    except InvalidTokenError:
        return None


def verify_refresh_token(token: str) -> Optional[dict]:
    """Verify refresh token and return payload."""
    try:
        payload = jwt.decode(token, config.jwt_refresh_secret, algorithms=["HS256"])
        if payload.get("type") != "refresh":
            return None
        
        # Check if token exists in database
        token_hash = hashlib.sha256(token.encode()).hexdigest()
        with get_db_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT user_id FROM refresh_tokens WHERE token_hash = %s AND expires_at > NOW()",
                    (token_hash,)
                )
                if not cur.fetchone():
                    return None
        
        return payload
    except InvalidTokenError:
        return None


def revoke_refresh_token(token: str) -> bool:
    """Revoke refresh token."""
    token_hash = hashlib.sha256(token.encode()).hexdigest()
    try:
        with get_db_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("DELETE FROM refresh_tokens WHERE token_hash = %s", (token_hash,))
                return cur.rowcount > 0
    except Exception:
        return False


class EnhancedHTTPRequestHandler(BaseHTTPRequestHandler):
    def _set_headers_json(self, code: int = 200) -> None:
        self.send_response(code)
        self.send_header("Content-type", "application/json")
        self.send_header("Access-Control-Allow-Origin", config.cors_origin)
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.end_headers()

    def do_OPTIONS(self):
        self._set_headers_json(204)

    def _read_json_body(self) -> Tuple[Optional[dict], Optional[str]]:
        try:
            content_length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            content_length = 0
        
        raw_body = self.rfile.read(content_length) if content_length > 0 else b""
        try:
            body = json.loads(raw_body.decode("utf-8") or "{}")
            return body, None
        except json.JSONDecodeError:
            return None, "Invalid JSON"

    def _get_client_ip(self) -> str:
        return self.client_address[0]

    def _send_error(self, code: int, message: str):
        self._set_headers_json(code)
        self.wfile.write(json.dumps({"error": message}).encode("utf-8"))

    def do_POST(self):
        client_ip = self._get_client_ip()
        path = self.path
        
        # Rate limiting
        if not check_rate_limit(client_ip, path.lstrip("/")):
            self._send_error(429, "Rate limit exceeded")
            return
        
        record_request(client_ip, path.lstrip("/"))
        
        body, err = self._read_json_body()
        if err:
            self._send_error(400, err)
            return
        
        assert body is not None
        
        try:
            if path == "/signup":
                self._handle_signup(body)
            elif path == "/login":
                self._handle_login(body, client_ip)
            elif path == "/refresh":
                self._handle_refresh(body)
            elif path == "/logout":
                self._handle_logout(body)
            else:
                self._send_error(404, "Not found")
        except Exception as e:
            logger.error(f"Error handling {path}: {e}")
            self._send_error(500, "Internal server error")

    def do_GET(self):
        path = self.path
        if path == "/profile":
            self._handle_profile()
        else:
            self._send_error(404, "Not found")

    def _handle_signup(self, body: dict):
        """Handle user signup."""
        # Validate input
        valid, message = validate_input(
            body, 
            ["username", "password"],
            {
                "username": validate_username,
                "password": validate_password,
                "email": validate_email
            }
        )
        if not valid:
            self._send_error(400, message)
            return
        
        username = body["username"].strip()
        password = body["password"]
        email = body.get("email", "").strip()
        
        try:
            with get_db_connection() as conn:
                with conn.cursor() as cur:
                    # Check if username exists
                    cur.execute("SELECT id FROM users WHERE username = %s", (username,))
                    if cur.fetchone():
                        self._send_error(409, "Username already exists")
                        return
                    
                    # Check email if provided
                    if email:
                        cur.execute("SELECT id FROM users WHERE email = %s", (email,))
                        if cur.fetchone():
                            self._send_error(409, "Email already exists")
                            return
                    
                    # Create user
                    pw_hash, pw_salt = pbkdf2_hash_password(password)
                    cur.execute(
                        "INSERT INTO users (username, email, password_hash, password_salt) VALUES (%s, %s, %s, %s)",
                        (username, email, pw_hash, pw_salt)
                    )
                    user_id = cur.lastrowid
                    
                    # Generate tokens
                    access_token, refresh_token = generate_tokens(user_id, username)
                    
                    self._set_headers_json(201)
                    self.wfile.write(json.dumps({
                        "message": "User created successfully",
                        "access_token": access_token,
                        "refresh_token": refresh_token,
                        "user": {"id": user_id, "username": username, "email": email}
                    }).encode("utf-8"))
                    
        except Exception as e:
            logger.error(f"Signup error: {e}")
            self._send_error(500, "Failed to create user")

    def _handle_login(self, body: dict, client_ip: str):
        """Handle user login."""
        # Validate input
        valid, message = validate_input(body, ["username", "password"])
        if not valid:
            self._send_error(400, message)
            return
        
        username = body["username"].strip()
        password = body["password"]
        
        try:
            with get_db_connection() as conn:
                with conn.cursor() as cur:
                    cur.execute(
                        "SELECT id, username, email, password_hash, password_salt, is_active FROM users WHERE username = %s",
                        (username,)
                    )
                    user = cur.fetchone()
                    
                    if not user or not user["is_active"]:
                        self._send_error(401, "Invalid credentials")
                        return
                    
                    if not verify_password(password, user["password_hash"], user["password_salt"]):
                        self._send_error(401, "Invalid credentials")
                        return
                    
                    # Generate tokens
                    access_token, refresh_token = generate_tokens(user["id"], user["username"])
                    
                    self._set_headers_json(200)
                    self.wfile.write(json.dumps({
                        "message": "Login successful",
                        "access_token": access_token,
                        "refresh_token": refresh_token,
                        "user": {"id": user["id"], "username": user["username"], "email": user["email"]}
                    }).encode("utf-8"))
                    
        except Exception as e:
            logger.error(f"Login error: {e}")
            self._send_error(500, "Login failed")

    def _handle_refresh(self, body: dict):
        """Handle token refresh."""
        refresh_token = body.get("refresh_token", "")
        if not refresh_token:
            self._send_error(400, "refresh_token required")
            return
        
        payload = verify_refresh_token(refresh_token)
        if not payload:
            self._send_error(401, "Invalid refresh token")
            return
        
        # Generate new tokens
        access_token, new_refresh_token = generate_tokens(payload["user_id"], payload["username"])
        
        # Revoke old refresh token
        revoke_refresh_token(refresh_token)
        
        self._set_headers_json(200)
        self.wfile.write(json.dumps({
            "access_token": access_token,
            "refresh_token": new_refresh_token
        }).encode("utf-8"))

    def _handle_logout(self, body: dict):
        """Handle logout."""
        refresh_token = body.get("refresh_token", "")
        if not refresh_token:
            self._send_error(400, "refresh_token required")
            return
        
        if revoke_refresh_token(refresh_token):
            self._set_headers_json(200)
            self.wfile.write(json.dumps({"message": "Logged out successfully"}).encode("utf-8"))
        else:
            self._send_error(400, "Invalid refresh token")

    def _handle_profile(self):
        """Handle profile endpoint."""
        auth_header = self.headers.get("Authorization", "")
        if not auth_header.startswith("Bearer "):
            self._send_error(401, "Authorization header required")
            return
        
        token = auth_header[7:]  # Remove "Bearer "
        payload = verify_access_token(token)
        if not payload:
            self._send_error(401, "Invalid access token")
            return
        
        try:
            with get_db_connection() as conn:
                with conn.cursor() as cur:
                    cur.execute(
                        "SELECT id, username, email, created_at FROM users WHERE id = %s",
                        (payload["user_id"],)
                    )
                    user = cur.fetchone()
                    if not user:
                        self._send_error(404, "User not found")
                        return
                    
                    self._set_headers_json(200)
                    self.wfile.write(json.dumps({"user": user}).encode("utf-8"))
                    
        except Exception as e:
            logger.error(f"Profile error: {e}")
            self._send_error(500, "Failed to fetch profile")


def main():
    """Main function to start the server."""
    try:
        ensure_schema_exists()
        logger.info(f"Starting enhanced JWT auth server on port {config.server_port}")
        
        with socketserver.TCPServer((config.server_host, config.server_port), EnhancedHTTPRequestHandler) as httpd:
            logger.info(f"Server running on http://{config.server_host or 'localhost'}:{config.server_port}")
            httpd.serve_forever()
    except KeyboardInterrupt:
        logger.info("Server stopped")
    except Exception as e:
        logger.error(f"Server error: {e}")
        raise


if __name__ == "__main__":
    main()
