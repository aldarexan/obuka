"""Test suite for JWT Auth Enhanced Server

Run tests: python test_jwt_auth.py
"""
import json
import time
import unittest
import threading
import requests
from unittest.mock import patch, MagicMock


class TestJWTAuthServer(unittest.TestCase):
    """Test cases for the enhanced JWT auth server."""
    
    @classmethod
    def setUpClass(cls):
        """Set up test environment."""
        cls.base_url = "http://localhost:8002"
        cls.test_username = "testuser"
        cls.test_password = "testpass123"
        cls.test_email = "test@example.com"
        
        # Start server in background thread
        cls.server_thread = threading.Thread(target=cls._start_server)
        cls.server_thread.daemon = True
        cls.server_thread.start()
        
        # Wait for server to start
        time.sleep(2)
    
    @classmethod
    def _start_server(cls):
        """Start the server for testing."""
        from jwt_auth_enhanced import main
        main()
    
    def setUp(self):
        """Set up each test."""
        # Clean up test user if exists
        try:
            response = requests.post(f"{self.base_url}/login", json={
                "username": self.test_username,
                "password": self.test_password
            })
            if response.status_code == 200:
                # User exists, we'll clean up after test
                pass
        except:
            pass
    
    def tearDown(self):
        """Clean up after each test."""
        # Note: In a real test environment, you'd clean up the database
        pass
    
    def test_signup_success(self):
        """Test successful user signup."""
        response = requests.post(f"{self.base_url}/signup", json={
            "username": f"{self.test_username}_new",
            "password": self.test_password,
            "email": "new@example.com"
        })
        
        self.assertEqual(response.status_code, 201)
        data = response.json()
        self.assertIn("access_token", data)
        self.assertIn("refresh_token", data)
        self.assertIn("user", data)
        self.assertEqual(data["user"]["username"], f"{self.test_username}_new")
    
    def test_signup_duplicate_username(self):
        """Test signup with duplicate username."""
        # First signup
        requests.post(f"{self.base_url}/signup", json={
            "username": f"{self.test_username}_dup",
            "password": self.test_password
        })
        
        # Second signup with same username
        response = requests.post(f"{self.base_url}/signup", json={
            "username": f"{self.test_username}_dup",
            "password": self.test_password
        })
        
        self.assertEqual(response.status_code, 409)
        data = response.json()
        self.assertIn("error", data)
        self.assertIn("already exists", data["error"])
    
    def test_signup_invalid_input(self):
        """Test signup with invalid input."""
        # Missing username
        response = requests.post(f"{self.base_url}/signup", json={
            "password": self.test_password
        })
        self.assertEqual(response.status_code, 400)
        
        # Missing password
        response = requests.post(f"{self.base_url}/signup", json={
            "username": self.test_username
        })
        self.assertEqual(response.status_code, 400)
        
        # Invalid username (too short)
        response = requests.post(f"{self.base_url}/signup", json={
            "username": "ab",
            "password": self.test_password
        })
        self.assertEqual(response.status_code, 400)
        
        # Invalid password (too short)
        response = requests.post(f"{self.base_url}/signup", json={
            "username": self.test_username,
            "password": "123"
        })
        self.assertEqual(response.status_code, 400)
    
    def test_login_success(self):
        """Test successful login."""
        # First create a user
        signup_response = requests.post(f"{self.base_url}/signup", json={
            "username": f"{self.test_username}_login",
            "password": self.test_password
        })
        self.assertEqual(signup_response.status_code, 201)
        
        # Then login
        response = requests.post(f"{self.base_url}/login", json={
            "username": f"{self.test_username}_login",
            "password": self.test_password
        })
        
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertIn("access_token", data)
        self.assertIn("refresh_token", data)
        self.assertIn("user", data)
    
    def test_login_invalid_credentials(self):
        """Test login with invalid credentials."""
        response = requests.post(f"{self.base_url}/login", json={
            "username": "nonexistent",
            "password": "wrongpass"
        })
        
        self.assertEqual(response.status_code, 401)
        data = response.json()
        self.assertIn("error", data)
    
    def test_token_refresh(self):
        """Test token refresh functionality."""
        # Create user and login
        signup_response = requests.post(f"{self.base_url}/signup", json={
            "username": f"{self.test_username}_refresh",
            "password": self.test_password
        })
        self.assertEqual(signup_response.status_code, 201)
        refresh_token = signup_response.json()["refresh_token"]
        
        # Refresh token
        response = requests.post(f"{self.base_url}/refresh", json={
            "refresh_token": refresh_token
        })
        
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertIn("access_token", data)
        self.assertIn("refresh_token", data)
        self.assertNotEqual(refresh_token, data["refresh_token"])  # New refresh token
    
    def test_token_refresh_invalid_token(self):
        """Test refresh with invalid token."""
        response = requests.post(f"{self.base_url}/refresh", json={
            "refresh_token": "invalid_token"
        })
        
        self.assertEqual(response.status_code, 401)
        data = response.json()
        self.assertIn("error", data)
    
    def test_logout(self):
        """Test logout functionality."""
        # Create user and login
        signup_response = requests.post(f"{self.base_url}/signup", json={
            "username": f"{self.test_username}_logout",
            "password": self.test_password
        })
        self.assertEqual(signup_response.status_code, 201)
        refresh_token = signup_response.json()["refresh_token"]
        
        # Logout
        response = requests.post(f"{self.base_url}/logout", json={
            "refresh_token": refresh_token
        })
        
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertIn("message", data)
        
        # Try to use the same refresh token (should fail)
        response = requests.post(f"{self.base_url}/refresh", json={
            "refresh_token": refresh_token
        })
        self.assertEqual(response.status_code, 401)
    
    def test_profile_access(self):
        """Test profile endpoint with valid token."""
        # Create user and login
        signup_response = requests.post(f"{self.base_url}/signup", json={
            "username": f"{self.test_username}_profile",
            "password": self.test_password,
            "email": "profile@example.com"
        })
        self.assertEqual(signup_response.status_code, 201)
        access_token = signup_response.json()["access_token"]
        
        # Access profile
        headers = {"Authorization": f"Bearer {access_token}"}
        response = requests.get(f"{self.base_url}/profile", headers=headers)
        
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertIn("user", data)
        self.assertEqual(data["user"]["username"], f"{self.test_username}_profile")
    
    def test_profile_access_no_token(self):
        """Test profile endpoint without token."""
        response = requests.get(f"{self.base_url}/profile")
        self.assertEqual(response.status_code, 401)
    
    def test_profile_access_invalid_token(self):
        """Test profile endpoint with invalid token."""
        headers = {"Authorization": "Bearer invalid_token"}
        response = requests.get(f"{self.base_url}/profile", headers=headers)
        self.assertEqual(response.status_code, 401)
    
    def test_cors_headers(self):
        """Test CORS headers are present."""
        response = requests.options(f"{self.base_url}/signup")
        self.assertIn("Access-Control-Allow-Origin", response.headers)
        self.assertIn("Access-Control-Allow-Methods", response.headers)
    
    def test_invalid_json(self):
        """Test handling of invalid JSON."""
        response = requests.post(
            f"{self.base_url}/signup",
            data="invalid json",
            headers={"Content-Type": "application/json"}
        )
        self.assertEqual(response.status_code, 400)
    
    def test_nonexistent_endpoint(self):
        """Test nonexistent endpoint."""
        response = requests.post(f"{self.base_url}/nonexistent", json={})
        self.assertEqual(response.status_code, 404)


class TestPasswordHashing(unittest.TestCase):
    """Test password hashing functions."""
    
    def test_password_hashing(self):
        """Test password hashing and verification."""
        from jwt_auth_enhanced import pbkdf2_hash_password, verify_password
        
        password = "testpassword123"
        hash1, salt1 = pbkdf2_hash_password(password)
        
        # Same password should produce different hashes with different salts
        hash2, salt2 = pbkdf2_hash_password(password)
        self.assertNotEqual(hash1, hash2)
        self.assertNotEqual(salt1, salt2)
        
        # Verification should work
        self.assertTrue(verify_password(password, hash1, salt1))
        self.assertTrue(verify_password(password, hash2, salt2))
        
        # Wrong password should fail
        self.assertFalse(verify_password("wrongpassword", hash1, salt1))


class TestInputValidation(unittest.TestCase):
    """Test input validation functions."""
    
    def test_username_validation(self):
        """Test username validation."""
        from jwt_auth_enhanced import validate_username
        
        # Valid usernames
        self.assertTrue(validate_username("user123")[0])
        self.assertTrue(validate_username("user_name")[0])
        self.assertTrue(validate_username("user-name")[0])
        
        # Invalid usernames
        self.assertFalse(validate_username("ab")[0])  # Too short
        self.assertFalse(validate_username("a" * 51)[0])  # Too long
        self.assertFalse(validate_username("user@name")[0])  # Invalid character
    
    def test_password_validation(self):
        """Test password validation."""
        from jwt_auth_enhanced import validate_password
        
        # Valid passwords
        self.assertTrue(validate_password("password123")[0])
        
        # Invalid passwords
        self.assertFalse(validate_password("123")[0])  # Too short
        self.assertFalse(validate_password("a" * 129)[0])  # Too long
    
    def test_email_validation(self):
        """Test email validation."""
        from jwt_auth_enhanced import validate_email
        
        # Valid emails
        self.assertTrue(validate_email("user@example.com")[0])
        
        # Invalid emails
        self.assertFalse(validate_email("userexample.com")[0])  # No @
        self.assertFalse(validate_email("user@")[0])  # No domain


if __name__ == "__main__":
    print("Starting JWT Auth Enhanced Server Tests...")
    print("Note: Make sure the server is not already running on port 8002")
    print("Tests will start the server automatically")
    
    # Run tests
    unittest.main(verbosity=2)
