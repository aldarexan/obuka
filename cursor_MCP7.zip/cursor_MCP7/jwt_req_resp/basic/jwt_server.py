"""Simple JWT server endpoints (vanilla Python http.server)

POST /issue  -> body: {"secret": str, "user_id": int, "exp_seconds": int?}
                returns: {"token": str, "payload": {...}}
POST /verify -> body: {"secret": str, "token": str}
                returns: {"valid": bool, "decoded"?: object, "error"?: str}
"""
import jwt
import time
import json
import socketserver
from http.server import BaseHTTPRequestHandler
from jwt import InvalidTokenError #err specificity


class SimpleHTTPRequestHandler(BaseHTTPRequestHandler):
    def _set_headers_json(self, code: int = 200) -> None:
        self.send_response(code)
        self.send_header("Content-type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
        self.end_headers()

    def do_OPTIONS(self):  # CORS preflight
        self._set_headers_json(204)

    def do_POST(self):
        content_length = int(self.headers.get('Content-Length', '0'))
        #https://stackoverflow.com/questions/50880481/how-does-the-python-baserequesthandler-rfile-read-method-work
        #https://docs.python.org/2/library/basehttpserver.html#BaseHTTPServer.BaseHTTPRequestHandler.rfile
        raw_body = self.rfile.read(content_length) if content_length > 0 else b''
        try:
            body = json.loads(raw_body.decode('utf-8') or '{}')
        except Exception:
            self._set_headers_json(400)
            self.wfile.write(json.dumps({"error": "Invalid JSON"}).encode('utf-8'))
            return

        if self.path == '/issue':
            secret = body.get('secret')
            user_id = body.get('user_id')
            exp_seconds = body.get('exp_seconds')
            print(secret, user_id, exp_seconds, 'issue')
            if not secret or user_id is None:
                self._set_headers_json(400)
                self.wfile.write(json.dumps({"error": "'secret' and 'user_id' are required"}).encode('utf-8'))
                return

            payload = {"user_id": int(user_id)}
            if isinstance(exp_seconds, int) and exp_seconds > 0:
                payload["exp"] = int(time.time()) + exp_seconds

            token = jwt.encode(payload, secret, algorithm='HS256')
            if isinstance(token, bytes):
                token = token.decode('utf-8')

            self._set_headers_json(200)
            self.wfile.write(json.dumps({"token": token, "payload": payload}).encode('utf-8'))
            return

        if self.path == '/verify':
            secret = body.get('secret')
            token = body.get('token')
            print(secret, token, 'verify')
            if not secret or not token:
                self._set_headers_json(400)
                self.wfile.write(json.dumps({"error": "'secret' and 'token' are required"}).encode('utf-8'))
                return
            try:
                decoded = jwt.decode(token, secret, algorithms=['HS256'])
                self._set_headers_json(200)
                self.wfile.write(json.dumps({"valid": True, "decoded": decoded}).encode('utf-8'))
            except InvalidTokenError as e:
                self._set_headers_json(200)
                self.wfile.write(json.dumps({"valid": False, "error": str(e)}).encode('utf-8'))
            return

        self._set_headers_json(404)
        self.wfile.write(json.dumps({"error": "Not found"}).encode('utf-8'))


with socketserver.TCPServer(("", 8000), SimpleHTTPRequestHandler) as httpd:
    print("Serving on port 8000...")
    httpd.serve_forever()

#Run the server: python req_resp_jwt/jwt_server.py
#Open the HTML file in the browser.
#Enter SECRET_KEY and user_id.