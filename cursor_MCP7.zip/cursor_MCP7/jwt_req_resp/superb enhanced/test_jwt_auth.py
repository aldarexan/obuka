"""Test suite (copy) placed in enhanced folder for convenience.
Run: python enhanced/test_jwt_auth.py
"""
import unittest

from pathlib import Path
import sys

# Ensure repository root on path to import server module
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from test_jwt_auth import *  # re-use the same tests

if __name__ == "__main__":
    unittest.main(verbosity=2)


