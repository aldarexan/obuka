#!/usr/bin/env node

const fs = require('fs');
const path = require('path');

function readJson(filePath) {
  const raw = fs.readFileSync(filePath, 'utf8');
  return JSON.parse(raw);
}

function isNonEmptyString(value) {
  return typeof value === 'string' && value.trim().length > 0;
}

function validateServerEntry(name, entry) {
  if (entry == null || typeof entry !== 'object') {
    throw new Error(`Server "${name}" must be an object`);
  }

  const hasUrl = Object.prototype.hasOwnProperty.call(entry, 'url');
  const hasCommand = Object.prototype.hasOwnProperty.call(entry, 'command');

  if (!hasUrl && !hasCommand) {
    throw new Error(`Server "${name}" must have either "url" or "command"`);
  }

  if (hasUrl) {
    if (!isNonEmptyString(entry.url)) {
      throw new Error(`Server "${name}": "url" must be a non-empty string`);
    }
  }

  if (hasCommand) {
    if (!isNonEmptyString(entry.command)) {
      throw new Error(`Server "${name}": "command" must be a non-empty string`);
    }
    if (entry.args !== undefined) {
      if (!Array.isArray(entry.args) || !entry.args.every(isNonEmptyString)) {
        throw new Error(`Server "${name}": "args" must be an array of non-empty strings`);
      }
    }
  }
}

function validateConfig(config) {
  if (config == null || typeof config !== 'object') {
    throw new Error('Config must be a JSON object');
  }
  if (!config.mcpServers || typeof config.mcpServers !== 'object') {
    throw new Error('Config must have an "mcpServers" object');
  }

  const serverNames = Object.keys(config.mcpServers);
  if (serverNames.length === 0) {
    throw new Error('"mcpServers" must contain at least one server');
  }

  for (const name of serverNames) {
    validateServerEntry(name, config.mcpServers[name]);
  }

  return { serverCount: serverNames.length };
}

function main() {
  const root = process.cwd();
  const files = [
   // path.join(root, 'cursor mcp 7.json'),
    path.join(root, '.cursor', 'mcp.json'),
  ];

  let hadError = false;

  for (const file of files) {
    try {
      if (!fs.existsSync(file)) {
        console.log(`[skip] ${path.relative(root, file)} (not found)`);
        continue;
      }
      const json = readJson(file);
      const info = validateConfig(json);
      console.log(`[ok] ${path.relative(root, file)} — servers: ${info.serverCount}`);
    } catch (err) {
      hadError = true;
      console.error(`[fail] ${path.relative(root, file)} — ${err.message}`);
    }
  }

  if (hadError) process.exit(1);
}

main();
