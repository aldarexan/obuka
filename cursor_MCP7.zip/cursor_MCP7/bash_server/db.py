"""
Simple MySQL database helper for user auth demo.

This module centralizes connection handling and basic user CRUD operations
against a MySQL database (e.g., XAMPP's MySQL running on port 3306).

Environment variables (see .env.example):
- DB_HOST, DB_PORT, DB_USER, DB_PASSWORD, DB_NAME

The functions here are intentionally straightforward and heavily commented
for maximum readability.
"""

import os
import contextlib
from typing import Any, Dict, Optional

import mysql.connector
from mysql.connector import Error as MySQLError


def get_db_config() -> Dict[str, Any]:
    """Read DB config from environment with sensible defaults for XAMPP."""
    return {
        "host": os.getenv("DB_HOST", "127.0.0.1"),
        "port": int(os.getenv("DB_PORT", "3306")),
        "user": os.getenv("DB_USER", "root"),
        # XAMPP's default MySQL may have an empty root password; override in .env
        "password": os.getenv("DB_PASSWORD", ""),
        "database": os.getenv("DB_NAME", "test"),
        "auth_plugin": os.getenv("DB_AUTH_PLUGIN") or None,
    }


@contextlib.contextmanager
def get_connection():
    """Yield a MySQL connection and ensure it is closed after use."""
    cfg = get_db_config()
    conn = None
    try:
        conn = mysql.connector.connect(**{k: v for k, v in cfg.items() if v is not None})
        yield conn
    finally:
        if conn is not None and conn.is_connected():
            conn.close()


def init_schema() -> None:
    """Create the minimal `users` table if it doesn't exist."""
    create_sql = (
        """
        CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(64) NOT NULL UNIQUE,
            email VARCHAR(255) NULL,
            password_hash VARCHAR(255) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        """
    )

    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(create_sql)
        conn.commit()


def find_user_by_username(username: str) -> Optional[Dict[str, Any]]:
    """Return a user row as dict, or None if not found."""
    sql = "SELECT id, username, email, password_hash, created_at FROM users WHERE username=%s"
    with get_connection() as conn:
        with conn.cursor(dictionary=True) as cur:
            cur.execute(sql, (username,))
            row = cur.fetchone()
            return row if row else None


def create_user(username: str, password_hash: str, email: Optional[str] = None) -> Dict[str, Any]:
    """Insert a new user and return the inserted row as dict."""
    sql = "INSERT INTO users (username, email, password_hash) VALUES (%s, %s, %s)"
    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(sql, (username, email, password_hash))
            user_id = cur.lastrowid
        conn.commit()

    # Read back the user row (including created_at timestamp)
    return get_user_by_id(user_id)


def get_user_by_id(user_id: int) -> Optional[Dict[str, Any]]:
    """Return a user by id as dict, or None if not found."""
    sql = "SELECT id, username, email, password_hash, created_at FROM users WHERE id=%s"
    with get_connection() as conn:
        with conn.cursor(dictionary=True) as cur:
            cur.execute(sql, (user_id,))
            row = cur.fetchone()
            return row if row else None


