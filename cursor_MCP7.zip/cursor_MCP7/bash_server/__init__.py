"""Package init for bash_server."""


