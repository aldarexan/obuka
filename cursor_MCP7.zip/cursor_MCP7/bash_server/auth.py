"""
JWT utilities and Flask decorators for simple auth.

This file provides helpers to generate and verify JWT tokens and a decorator
to protect routes. Tokens include `sub` (user id) and `username` claims, with
an expiration (exp). The expiration duration can be supplied by clients but is
clamped to a safe maximum to avoid excessively long-lived tokens.
"""

import os
import time
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Optional, Tuple

import jwt
from flask import request, jsonify


def get_jwt_secret() -> str:
    """Read JWT secret from env or use a local default for development."""
    return os.getenv("JWT_SECRET", "dev-secret-change-me")


def get_jwt_algorithm() -> str:
    return os.getenv("JWT_ALGORITHM", "HS256")


def clamp_exp_minutes(requested_minutes: Optional[int]) -> int:
    """Clamp requested expiration minutes to [1, MAX]."""
    default_minutes = int(os.getenv("JWT_DEFAULT_EXP_MINUTES", "15"))
    max_minutes = int(os.getenv("JWT_MAX_EXP_MINUTES", "1440"))  # up to 24h by default
    if not requested_minutes:
        return default_minutes
    return max(1, min(requested_minutes, max_minutes))


def generate_token(user: Dict[str, Any], exp_minutes: Optional[int] = None) -> str:
    """Generate a JWT for the given user dict."""
    minutes = clamp_exp_minutes(exp_minutes)
    exp = datetime.now(tz=timezone.utc) + timedelta(minutes=minutes)
    payload = {
        "sub": str(user["id"]),
        "username": user["username"],
        "exp": exp,
        "iat": datetime.now(tz=timezone.utc),
    }
    token = jwt.encode(payload, get_jwt_secret(), algorithm=get_jwt_algorithm())
    # PyJWT >= 2 returns str
    return token


def decode_token(token: str) -> Optional[Dict[str, Any]]:
    """Decode and validate a JWT. Return claims or None on failure."""
    try:
        claims = jwt.decode(token, get_jwt_secret(), algorithms=[get_jwt_algorithm()])
        return claims
    except jwt.ExpiredSignatureError:
        return None
    except jwt.InvalidTokenError:
        return None


def auth_required(view_func):
    """Flask decorator to enforce Bearer token authentication."""
    def wrapper(*args, **kwargs):
        auth_header = request.headers.get("Authorization", "")
        if not auth_header.startswith("Bearer "):
            return jsonify({"error": "Missing or invalid Authorization header"}), 401
        token = auth_header.split(" ", 1)[1].strip()
        claims = decode_token(token)
        if not claims:
            return jsonify({"error": "Invalid or expired token"}), 401
        # Attach claims to request context via kwargs for simplicity
        return view_func(claims=claims, *args, **kwargs)

    # Preserve function name for Flask's routing/debug friendliness
    wrapper.__name__ = getattr(view_func, "__name__", "wrapped")
    return wrapper


