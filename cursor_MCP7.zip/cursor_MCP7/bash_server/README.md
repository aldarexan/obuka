Project: Minimal Flask JWT Auth with MySQL (XAMPP)

Structure
- app.py: Flask app factory and routes (signup, login, profile)
- auth.py: JWT helpers and auth decorator
- db.py: MySQL helpers and users table schema
- public/index.html: Simple HTML/JS client for signup/login/profile
- requirements.txt: Python dependencies
- config.env.example: Template env vars (copy to config.env or export in shell)

Setup
1) Install dependencies
   pip install -r requirements.txt

2) Configure environment
   Copy config.env.example to config.env and adjust values, or export variables:
   - DB_HOST, DB_PORT, DB_USER, DB_PASSWORD, DB_NAME (use XAMPP MySQL)
   - JWT_SECRET, JWT_DEFAULT_EXP_MINUTES, JWT_MAX_EXP_MINUTES

3) Initialize schema
   Run the server and POST /init-db once (idempotent).

Run
   python -m bash_server.app
   Server defaults to http://localhost:8003 (override HOST/PORT via env)

Frontend
   Open http://localhost:8003/ to use the minimal client.

Security Notes
- Use strong JWT_SECRET in production.
- Prefer longer password hash parameters and HTTPS.
- Clamp token lifetimes with server-side limits.


