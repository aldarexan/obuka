"""
Minimal Flask backend with MySQL and JWT auth.

Features:
- Signup and Login endpoints
- Optional per-request token expiration (minutes), clamped server-side
- Protected profile endpoint requiring Bearer token
- DB schema bootstrap helper

This is intentionally minimal and heavily commented for clarity.
"""

import os
from typing import Any, Dict

from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS
from werkzeug.security import generate_password_hash, check_password_hash

from . import db
from .auth import generate_token, auth_required


def create_app() -> Flask:
    app = Flask(__name__, static_folder="public", static_url_path="/")
    CORS(app)

    # Load environment from config.env if present (development convenience)
    try:
        from dotenv import load_dotenv
        config_path = os.path.join(os.path.dirname(__file__), "config.env")
        if os.path.exists(config_path):
            load_dotenv(config_path)
    except Exception:
        # dotenv is optional
        pass

    # Health check endpoint to verify server is running
    @app.get("/health")
    def health():
        return jsonify({"status": "ok"})

    # One-time schema initialization helper (idempotent)
    @app.post("/init-db")
    def init_db():
        try:
            db.init_schema()
            return jsonify({"message": "Schema ensured"}), 200
        except Exception as exc:
            return jsonify({"error": str(exc)}), 500

    # Serve the demo frontend (index.html) from /
    @app.get("/")
    def index():
        return send_from_directory(app.static_folder, "index.html")

    # Signup: create a new user and return a JWT
    @app.post("/signup")
    def signup():
        payload = request.get_json(force=True, silent=True) or {}
        username = (payload.get("username") or "").strip()
        password = payload.get("password") or ""
        email = (payload.get("email") or None)
        exp_minutes = payload.get("exp_minutes")  # optional client-suggested token lifetime

        if not username or not password:
            return jsonify({"error": "username and password are required"}), 400

        if db.find_user_by_username(username):
            return jsonify({"error": "username already exists"}), 409

        # Hash the password (Werkzeug uses PBKDF2 by default here)
        password_hash = generate_password_hash(password)
        user = db.create_user(username=username, password_hash=password_hash, email=email)

        # Generate JWT token
        token = generate_token(user, exp_minutes=exp_minutes)
        user_public = {
            "id": user["id"],
            "username": user["username"],
            "email": user.get("email"),
            "created_at": user.get("created_at"),
        }
        return jsonify({"access_token": token, "user": user_public}), 201

    # Login: verify credentials and return a JWT
    @app.post("/login")
    def login():
        payload = request.get_json(force=True, silent=True) or {}
        username = (payload.get("username") or "").strip()
        password = payload.get("password") or ""
        exp_minutes = payload.get("exp_minutes")

        if not username or not password:
            return jsonify({"error": "username and password are required"}), 400

        user = db.find_user_by_username(username)
        if not user or not check_password_hash(user["password_hash"], password):
            return jsonify({"error": "invalid credentials"}), 401

        token = generate_token(user, exp_minutes=exp_minutes)
        user_public = {
            "id": user["id"],
            "username": user["username"],
            "email": user.get("email"),
            "created_at": user.get("created_at"),
        }
        return jsonify({"access_token": token, "user": user_public}), 200

    # Profile: protected resource demonstrating token usage
    @app.get("/profile")
    @auth_required
    def profile(claims):
        # Fetch the latest user record to show current profile data
        user_id = int(claims.get("sub"))
        user = db.get_user_by_id(user_id)
        if not user:
            return jsonify({"error": "user not found"}), 404
        user_public = {
            "id": user["id"],
            "username": user["username"],
            "email": user.get("email"),
            "created_at": user.get("created_at"),
        }
        return jsonify({"user": user_public}), 200

    return app


if __name__ == "__main__":
    # Allow overriding host/port via env; default to 0.0.0.0:8003
    host = os.getenv("HOST", "0.0.0.0")
    port = int(os.getenv("PORT", "8003"))
    application = create_app()
    application.run(host=host, port=port, debug=True)


