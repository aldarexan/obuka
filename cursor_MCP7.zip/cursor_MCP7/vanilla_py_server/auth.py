"""
JWT helpers for the vanilla HTTP server.
"""

import os
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Optional

import jwt


def get_jwt_secret() -> str:
    return os.getenv("JWT_SECRET", "dev-secret-change-me")


def get_jwt_algorithm() -> str:
    return os.getenv("JWT_ALGORITHM", "HS256")


def clamp_exp_minutes(requested_minutes: Optional[int]) -> int:
    default_minutes = int(os.getenv("JWT_DEFAULT_EXP_MINUTES", "15"))
    max_minutes = int(os.getenv("JWT_MAX_EXP_MINUTES", "1440"))
    if not requested_minutes:
        return default_minutes
    return max(1, min(requested_minutes, max_minutes))


def generate_token(user: Dict[str, Any], exp_minutes: Optional[int] = None) -> str:
    minutes = clamp_exp_minutes(exp_minutes)
    exp = datetime.now(tz=timezone.utc) + timedelta(minutes=minutes)
    payload = {
        "sub": str(user["id"]),
        "username": user["username"],
        "exp": exp,
        "iat": datetime.now(tz=timezone.utc),
    }
    token = jwt.encode(payload, get_jwt_secret(), algorithm=get_jwt_algorithm())
    return token


def decode_token(token: str) -> Optional[Dict[str, Any]]:
    try:
        return jwt.decode(token, get_jwt_secret(), algorithms=[get_jwt_algorithm()])
    except jwt.ExpiredSignatureError:
        return None
    except jwt.InvalidTokenError:
        return None


