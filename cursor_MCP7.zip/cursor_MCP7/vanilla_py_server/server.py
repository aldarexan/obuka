"""
Vanilla Python HTTP server implementing JWT auth with MySQL.

Endpoints:
- GET  /                  -> serves public/index.html
- GET  /health            -> health check
- POST /init-db           -> ensure users table exists
- POST /signup            -> create user, return JWT
- POST /login             -> authenticate, return JWT
- GET  /profile           -> protected, requires Bearer token

This keeps code very simple and heavily commented. Not production-hardened.
"""

import os
import json
import mimetypes
import hashlib
import secrets
import base64
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse

def generate_password_hash(password: str) -> str:
    # PBKDF2-HMAC-SHA256 with random 16-byte salt and 260000 iterations
    iterations = 260000
    salt = secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, iterations)
    # Store in a readable, portable format
    return f"pbkdf2_sha256${iterations}${base64.b64encode(salt).decode()}${base64.b64encode(dk).decode()}"


def check_password_hash(stored: str, password: str) -> bool:
    try:
        algo, iter_str, salt_b64, hash_b64 = stored.split('$', 3)
        if algo != 'pbkdf2_sha256':
            return False
        iterations = int(iter_str)
        salt = base64.b64decode(salt_b64)
        expected = base64.b64decode(hash_b64)
        candidate = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, iterations)
        # Use secrets.compare_digest to avoid timing leaks
        return secrets.compare_digest(candidate, expected)
    except Exception:
        return False

try:
    # Prefer package-relative imports (python -m vanilla_py_server.server)
    from . import db
    from .auth import generate_token, decode_token
except Exception:
    # Fallback for running this file directly (python vanilla_py_server/server.py)
    import sys
    sys.path.append(os.path.dirname(os.path.dirname(__file__)))
    from vanilla_py_server import db
    from vanilla_py_server.auth import generate_token, decode_token


PUBLIC_DIR = os.path.join(os.path.dirname(__file__), "public")


def load_env_from_file():
    # Development convenience: load environment from config.env if present
    try:
        from dotenv import load_dotenv # type: ignore
        path = os.path.join(os.path.dirname(__file__), "config.env")
        if os.path.exists(path):
            load_dotenv(path)
    except Exception:
        pass


class Handler(BaseHTTPRequestHandler):
    # Utility helpers
    def _set_cors(self):
        origin = os.getenv("CORS_ORIGIN", "*")
        self.send_header("Access-Control-Allow-Origin", origin)
        self.send_header("Vary", "Origin")
        self.send_header("Access-Control-Allow-Credentials", "false")
        self.send_header(
            "Access-Control-Allow-Headers",
            os.getenv("CORS_ALLOW_HEADERS", "Content-Type, Authorization"),
        )
        self.send_header(
            "Access-Control-Allow-Methods",
            os.getenv("CORS_ALLOW_METHODS", "GET, POST, OPTIONS"),
        )

    def _send_json(self, obj, status=200):
        data = json.dumps(obj).encode("utf-8")
        self.send_response(status)
        self._set_cors()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _read_json(self):
        length = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(length) if length else b""
        if not raw:
            return {}
        try:
            return json.loads(raw.decode("utf-8"))
        except Exception:
            return {}

    def _serve_static(self, path: str):
        # Only serve within PUBLIC_DIR; default to index.html
        if path == "/":
            path = "/index.html"
        fs_path = os.path.normpath(os.path.join(PUBLIC_DIR, path.lstrip("/")))
        if not fs_path.startswith(PUBLIC_DIR) or not os.path.exists(fs_path):
            self._send_json({"error": "Not found"}, status=404)
            return
        ctype = mimetypes.guess_type(fs_path)[0] or "application/octet-stream"
        with open(fs_path, "rb") as f:
            data = f.read()
        self.send_response(200)
        self._set_cors()
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    # Routing
    def do_OPTIONS(self):
        # Respond to CORS preflight for any path
        self.send_response(204)
        self._set_cors()
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == "/health":
            return self._send_json({"status": "ok"})
        if parsed.path == "/profile":
            # Protected: require Bearer token
            auth_header = self.headers.get("Authorization", "")
            if not auth_header.startswith("Bearer "):
                return self._send_json({"error": "Missing or invalid Authorization header"}, status=401)
            token = auth_header.split(" ", 1)[1].strip()
            claims = decode_token(token)
            if not claims:
                return self._send_json({"error": "Invalid or expired token"}, status=401)
            user_id = int(claims.get("sub"))
            user = db.get_user_by_id(user_id)
            if not user:
                return self._send_json({"error": "user not found"}, status=404)
            user_public = {
                "id": user["id"],
                "username": user["username"],
                "email": user.get("email"),
                "created_at": user.get("created_at"),
            }
            return self._send_json({"user": user_public})

        # Serve static for all other GETs
        return self._serve_static(parsed.path)

    def do_POST(self):
        parsed = urlparse(self.path)
        if parsed.path == "/init-db":
            try:
                db.init_schema()
                return self._send_json({"message": "Schema ensured"})
            except Exception as exc:
                return self._send_json({"error": str(exc)}, status=500)

        if parsed.path == "/signup":
            data = self._read_json()
            username = (data.get("username") or "").strip()
            password = data.get("password") or ""
            email = (data.get("email") or None)
            exp_minutes = data.get("exp_minutes")
            if not username or not password:
                return self._send_json({"error": "username and password are required"}, status=400)
            if db.find_user_by_username(username):
                return self._send_json({"error": "username already exists"}, status=409)
            password_hash = generate_password_hash(password)
            user = db.create_user(username=username, password_hash=password_hash, email=email)
            token = generate_token(user, exp_minutes=exp_minutes)
            user_public = {
                "id": user["id"],
                "username": user["username"],
                "email": user.get("email"),
                "created_at": user.get("created_at"),
            }
            return self._send_json({"access_token": token, "user": user_public}, status=201)

        if parsed.path == "/login":
            data = self._read_json()
            username = (data.get("username") or "").strip()
            password = data.get("password") or ""
            exp_minutes = data.get("exp_minutes")
            if not username or not password:
                return self._send_json({"error": "username and password are required"}, status=400)
            user = db.find_user_by_username(username)
            if not user or not check_password_hash(user["password_hash"], password):
                return self._send_json({"error": "invalid credentials"}, status=401)
            token = generate_token(user, exp_minutes=exp_minutes)
            user_public = {
                "id": user["id"],
                "username": user["username"],
                "email": user.get("email"),
                "created_at": user.get("created_at"),
            }
            return self._send_json({"access_token": token, "user": user_public})

        return self._send_json({"error": "Not found"}, status=404)


def run():
    load_env_from_file()
    host = os.getenv("HOST", "0.0.0.0")
    port = int(os.getenv("PORT", "8004"))
    httpd = HTTPServer((host, port), Handler)
    print(f"Serving on http://{host}:{port}")
    httpd.serve_forever()


if __name__ == "__main__":
    run()


