Project: Vanilla Python JWT Auth with MySQL

Structure
- server.py: http.server-based app with endpoints
- auth.py: JWT helpers
- db.py: MySQL helpers and schema
- public/index.html: Simple client
- requirements.txt: Dependencies
- config.env.example: Template env vars (copy to config.env)

Setup
1) Install deps
   pip install -r requirements.txt

2) Configure environment
   Copy config.env.example to config.env and adjust DB/JWT values.

3) Run server
   python -m vanilla_py_server.server
   Defaults to http://localhost:8004

4) Initialize schema
   curl -X POST http://localhost:8004/init-db

5) Use client
   Open http://localhost:8004/ and sign up / log in / load profile.

Notes
- Use a strong JWT_SECRET and HTTPS in production.
- Keep token lifetimes reasonable; server clamps max minutes.


