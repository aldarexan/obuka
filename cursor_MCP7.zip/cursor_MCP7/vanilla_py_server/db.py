"""
SQLAlchemy-based database helper for user auth demo (vanilla HTTP server).

Environment variables (see config.env.example):
- DB_HOST, DB_PORT, DB_USER, DB_PASSWORD, DB_NAME
"""

import os
from typing import Any, Dict, Optional

from sqlalchemy import create_engine, text
from sqlalchemy.orm import declarative_base, Session, Mapped, mapped_column
from sqlalchemy.types import Integer, String, DateTime
from sqlalchemy.sql import func


def get_db_config() -> Dict[str, Any]:
    return {
        "host": os.getenv("DB_HOST", "127.0.0.1"),
        "port": int(os.getenv("DB_PORT", "3306")),
        "user": os.getenv("DB_USER", "root"),
        "password": os.getenv("DB_PASSWORD", ""),
        "database": os.getenv("DB_NAME", "test"),
    }


Base = declarative_base()


def _engine_url(cfg: Dict[str, Any]) -> str:
    # Use PyMySQL driver under SQLAlchemy
    return (
        f"mysql+pymysql://{cfg['user']}:{cfg['password']}@{cfg['host']}:{cfg['port']}/{cfg['database']}"
    )


def _ensure_database(cfg: Dict[str, Any]) -> None:
    # Create database if missing by connecting to server without DB
    server_url = f"mysql+pymysql://{cfg['user']}:{cfg['password']}@{cfg['host']}:{cfg['port']}/"
    server_engine = create_engine(server_url, pool_pre_ping=True)
    with server_engine.connect() as conn:
        conn.execute(text(
            f"CREATE DATABASE IF NOT EXISTS `{cfg['database']}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
        ))


def get_engine():
    cfg = get_db_config()
    _ensure_database(cfg)
    engine = create_engine(_engine_url(cfg), pool_pre_ping=True)
    return engine


class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    username: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)
    email: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[Any] = mapped_column(DateTime(timezone=True), server_default=func.now())


def init_schema() -> None:
    engine = get_engine()
    Base.metadata.create_all(engine)


def find_user_by_username(username: str) -> Optional[Dict[str, Any]]:
    engine = get_engine()
    with Session(engine) as session:
        user = session.query(User).filter(User.username == username).one_or_none()
        if not user:
            return None
        return {
            "id": user.id,
            "username": user.username,
            "email": user.email,
            "password_hash": user.password_hash,
            "created_at": user.created_at,
        }


def create_user(username: str, password_hash: str, email: Optional[str] = None) -> Dict[str, Any]:
    engine = get_engine()
    with Session(engine) as session:
        user = User(username=username, email=email, password_hash=password_hash)
        session.add(user)
        session.commit()
        session.refresh(user)
        return {
            "id": user.id,
            "username": user.username,
            "email": user.email,
            "password_hash": user.password_hash,
            "created_at": user.created_at,
        }


def get_user_by_id(user_id: int) -> Optional[Dict[str, Any]]:
    engine = get_engine()
    with Session(engine) as session:
        user = session.get(User, user_id)
        if not user:
            return None
        return {
            "id": user.id,
            "username": user.username,
            "email": user.email,
            "password_hash": user.password_hash,
            "created_at": user.created_at,
        }


