"""Package init for vanilla_py_server."""


